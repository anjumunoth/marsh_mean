import { Component } from '@angular/core';
import { Products } from '../model/Products';
import { Cart } from '../model/Cart';

@Component({
  selector: 'app-product-display',
  templateUrl: './product-display.component.html',
  styleUrls: ['./product-display.component.css']
})
export class ProductDisplayComponent {
  productsArr: Products[];
  companyName: string;
  showAddToCart: boolean;
  selectedProduct: Products | null;

  constructor() {
    this.selectedProduct = null;
    this.companyName = "Marsh";
    this.showAddToCart = false;
    this.productsArr = [
      new Products(101, "Iphone 15 max pro", "../assets/iphone15ProMax.jpg", "Apple Iphone 15 pro max 256gb white colour", 112345, 12),
      new Products(102, "Google Pixel 8", "../assets/googlePixel8.jpg", "Apple Iphone 15 pro max 256gb white colour", 11345, 1),
      new Products(103, "One plus 8t", "../assets/oneplus8T.jpg", "Apple Iphone 15 pro max 256gb white colour", 56782, 5),
      new Products(104, "Samsung Fold", "../assets/samsungFold.jpg", "Apple Iphone 15 pro max 256gb white colour", 151345, 7),
      new Products(105, "Vivo Y 16", "../assets/vivoY16.jpg", "Apple Iphone 15 pro max 256gb white colour", 12345, 9),
    ];
  }
  addToCart(selectedProduct: Products) {
    alert("Button clicked" + selectedProduct.productName);
    this.showAddToCart = true;
    this.selectedProduct = selectedProduct;
  }
  changeCompanyName() {
    this.companyName = "Apple";
  }
  sendDataFromAddToCartToPDEventHandler(cartObj: Cart | null) {
    if (cartObj != null) {
      // update the quantity in productsArr
      var pos = this.productsArr.findIndex(product => product.productId == cartObj.productId);
      if (pos >= 0) {
        this.productsArr[pos].quantity = this.productsArr[pos].quantity - cartObj.quantitySelected;
      }

      // unmount the child component
      this.showAddToCart = false;
      // selectedProduct -- null
      this.selectedProduct = null;
    }
  }
  sendCancelEventFromAddToCartToPDEventHandler() {
    this.showAddToCart = false;
    this.selectedProduct = null;
  }

}
