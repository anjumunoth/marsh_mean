import { Component } from '@angular/core';
import { Products } from '../model/Products';

@Component({
  selector: 'app-search-products',
  templateUrl: './search-products.component.html',
  styleUrls: ['./search-products.component.css']
})
export class SearchProductsComponent {
  productsArr: Products[];
  searchText: string;
  fieldName: string;
  fieldNameArr: string[];
  selectedProduct: Products | null;
  constructor() {
    this.selectedProduct = null;
    this.productsArr = [
      new Products(101, "Iphone 15 max pro", "../assets/iphone15ProMax.jpg", "Apple Iphone 15 pro max 256gb white colour", 112345, 12),
      new Products(102, "Google Pixel 8", "../assets/googlePixel8.jpg", "Apple Iphone 15 pro max 256gb white colour", 11345, 1),
      new Products(103, "One plus 8t", "../assets/oneplus8T.jpg", "Apple Iphone 15 pro max 256gb white colour", 56782, 5),
      new Products(104, "Samsung Fold", "../assets/samsungFold.jpg", "Apple Iphone 15 pro max 256gb white colour", 151345, 7),
      new Products(105, "Vivo Y 16", "../assets/vivoY16.jpg", "Apple Iphone 15 pro max 256gb white colour", 12345, 9),
    ];
    this.searchText = "";
    this.fieldName = "";
    this.fieldNameArr = ["productId", "productName", "price", "quantity", "description"];

  }
  searchEventHandler(text: string, fieldName: string) {
    this.searchText = text;
    this.fieldName = fieldName;
  }
  editEventHandler(selectedProduct: Products) {
    this.selectedProduct = selectedProduct;
  }
}
