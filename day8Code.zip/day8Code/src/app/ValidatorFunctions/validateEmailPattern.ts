export function validateEmailPattern() {

}