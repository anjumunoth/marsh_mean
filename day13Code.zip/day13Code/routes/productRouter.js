var express = require('express');
var { addProduct, fetchAllProducts } = require("../controller/productController");


var productsRouter = express.Router();


productsRouter.get("/", (request, response) => {
    // url : get /products
    var result = fetchAllProducts();
    if (result.status) {
        response.json(result.data);
    }
    else {
        response.status(200).json(result.data);
    }

})
productsRouter.get("/:productId", () => {
    // url : get /products
})
productsRouter.post("/", addProduct);
productsRouter.put("/", () => {
    // url : get /products
})
productsRouter.delete("/", () => {
    // url : get /products
})

module.exports = productsRouter;


/*
(request, response) => {

    var resultPromise = addProduct();
    resultPromise
        .then((data) => {
            response.json(data);
        })
        .catch((err) => {
            response.status(400).json(err);
        })


    // if (result.status) {
    //     response.json(result.data);
    // }
    // else {
    //     response.status(400).json(result.data);
    // }
}
    */