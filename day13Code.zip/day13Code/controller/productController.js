var { insertProduct, getAllProducts } = require("../model/productModel");

function addProduct(request, response) {

    var resultPromise = insertProduct();
    resultPromise
        .then((data) => {
            response.json(data);
        })
        .catch((err) => {
            response.status(400).json(err);
        })


}




function fetchAllProducts() {
    var resultArr = getAllProducts();
    if (resultArr) {
        return {
            status: true,
            data: resultArr
        }
    }
    else {
        return {
            status: false,
            data: []
        }
    }
}

module.exports = {
    addProduct,
    fetchAllProducts
}

