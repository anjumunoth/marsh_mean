const { MongoClient } = require("mongodb");
const Products = require("./Products");

const uri = "mongodb://127.0.0.1:27017";

const client = new MongoClient(uri);
var db;
async function connectDB() {
    try {
        await client.connect();
        console.log("Connected to mongodb server");
        db = client.db("shoppingCartDb");
        return db;
    }
    catch (err) {
        console.log(err);
    }

}

function disconnectDB() {
    client.close();
}


function insertProduct() {
    var myPromise = new Promise((resolve, reject) => {
        connectDB()
            .then((db) => {
                const collection = db.collection("products");
                var productToBeInserted = new Products(102, "Iphone 15 max pro", "../assets/iphone15ProMax.jpg", "Apple Iphone 15 pro max 256gb white colour", 112345, 12);
                collection.insertOne(productToBeInserted);
                resolve("Insertion successful");


            })

            .catch((err) => {
                console.log(err);
                reject("Insertion failed");

            })

    })
    return myPromise;


}
function getAllProducts() {
    connectDB()
        .then((db) => {
            const collection = db.collection("products");
            var resultArr = collection.find({}).toArray();
            return resultArr;

        })
        .catch((err) => {
            console.log(err);
        })


}

module.exports = { connectDB, disconnectDB, insertProduct, getAllProducts };



