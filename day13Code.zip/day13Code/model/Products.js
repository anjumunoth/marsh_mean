// export class Products {
//     constructor(public productId: number, public productName: string, public imageUrl: string, public description: string, public price: number, public quantity: number) {

//     }
// }
class Products {
    productId;
    productName;
    imageUrl;
    description;
    price;
    quantity;
    constructor(productId,
        productName,
        imageUrl,
        description,
        price,
        quantity) {
        this.productId = productId;
        this.productName = productName;
        this.description = description;
        this.imageUrl = imageUrl;
        this.price = price;
        this.quantity = quantity;
    }
}

module.exports=Products;
