import { Component } from '@angular/core';

@Component({
  selector: 'app-register-template',
  templateUrl: './register-template.component.html',
  styleUrls: ['./register-template.component.css']
})
export class RegisterTemplateComponent {
  submitEventHandler(registerFormValues: any) {
    console.log(registerFormValues);
    // send this data to the server via POST request
  }
}
