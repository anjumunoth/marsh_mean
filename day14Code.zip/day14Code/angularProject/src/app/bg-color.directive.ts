import { Directive, ElementRef, HostListener, Input, OnInit } from '@angular/core';

@Directive({
  selector: '[appBgColor]'
})
export class BgColorDirective implements OnInit {
  @Input() appBgColor: string;
  @Input() myBorder: string;
  @HostListener('mouseenter') onMouseEnter() {
    this.elementRef.nativeElement.style.backgroundColor = 'yellow';
    this.elementRef.nativeElement.style.color = 'black';
  }
  @HostListener('mouseleave') onMouseLeave() {
    console.log(this.appBgColor);
    this.elementRef.nativeElement.style.backgroundColor = this.appBgColor ? this.appBgColor : 'red';
    this.elementRef.nativeElement.style.color = 'white';
  }
  constructor(private elementRef: ElementRef) {
    this.appBgColor = "red";
    elementRef.nativeElement.style.backgroundColor = 'red';
    elementRef.nativeElement.style.color = 'cyan';
    this.myBorder = "";


  }
  ngOnInit() {
    if (this.appBgColor) {
      this.elementRef.nativeElement.style.backgroundColor = this.appBgColor;
    }
    if (this.myBorder) {
      this.elementRef.nativeElement.style.border = this.myBorder;
    }

  }

}

/*
constructor
@Inputs will be assigned the data from the data
ngOnChanges
ngOnInit
*/
