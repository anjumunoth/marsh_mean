import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CartManagementService } from '../cart-management.service';
import { Cart } from '../model/Cart';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent {
  cartArr: Cart[];
  constructor(private router: Router, private cms: CartManagementService) {
    this.cartArr = cms.getAllCartItems();

  }
  proceedToPaymentEventHandler() {
    // navigate to /payments
    this.router.navigate(['/payments']);

  }
}
