import { Injectable } from '@angular/core';
import { Products } from './model/Products';
import { TalkWithServerService } from './talk-with-server.service';
import { Observable } from 'rxjs';

@Injectable()
export class ProductManagementService {
  productsArr: Products[];
  constructor(private talkWithServer: TalkWithServerService) {
    // this.productsArr = [
    //   new Products(101, "Iphone 15 max pro", "../assets/iphone15ProMax.jpg", "Apple Iphone 15 pro max 256gb white colour", 112345, 12),
    //   new Products(102, "Google Pixel 8", "../assets/googlePixel8.jpg", "Apple Iphone 15 pro max 256gb white colour", 11345, 1),
    //   new Products(103, "One plus 8t", "../assets/oneplus8T.jpg", "Apple Iphone 15 pro max 256gb white colour", 56782, 5),
    //   new Products(104, "Samsung Fold", "../assets/samsungFold.jpg", "Apple Iphone 15 pro max 256gb white colour", 151345, 7),
    //   new Products(105, "Vivo Y 16", "../assets/vivoY16.jpg", "Apple Iphone 15 pro max 256gb white colour", 12345, 9),
    // ];
    this.productsArr = [];;
  }
  addProductsItem(ProductsObj: Products) {
    this.productsArr.push(ProductsObj);
    console.log(this.productsArr)
  }
  getAllProductsItems(): Observable<Products[]> {
    // return this.productsArr;
    return this.talkWithServer.getProductsArr();

  }
  deleteProductsItem(productId: number) {
    var pos = this.productsArr.findIndex(item => item.productId == productId);
    if (pos >= 0) {
      this.productsArr.splice(pos, 1);
      return true;
    }
    else {
      return false;
    }
  }
  getproductInfo(productId: number): Observable<Products> {
    return this.talkWithServer.getParticularProduct(productId);

  }
}