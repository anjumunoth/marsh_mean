var express = require('express');
var { checkUser, addUser } = require("../controller/userController")

var usersRouter = express.Router();

usersRouter.post("/register", addUser);
usersRouter.get("/login", checkUser);

module.exports = usersRouter;


