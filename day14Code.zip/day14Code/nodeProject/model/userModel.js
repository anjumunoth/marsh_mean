const { MongoClient } = require("mongodb");
const Products = require("./Products");

const uri = "mongodb://127.0.0.1:27017";

const client = new MongoClient(uri);
var db;
async function connectDB() {
    try {
        await client.connect();
        console.log("Connected to mongodb server");
        db = client.db("shoppingCartDb");
        return db;
    }
    catch (err) {
        console.log(err);
    }

}

function disconnectDB() {
    client.close();
}


async function registerUser(userObj) {
    try {
        var db = await connectDB();
        const collection = db.collection("users");
        var result = await collection.insertOne(userObj);
        console.log(result);
        return { status: true, data: `User details inserted with inserted Id : ${result.insertedId}` };

    }

    catch (err) {
        console.error(err);
        throw err;
    }
}

async function validateUser(userObj) {
    try {
        var db = await connectDB();
        const collection = db.collection("users");
        var result = await collection.findOne({ emailId: userObj.emailId, password: userObj.password });
        // if (result) {
        //     return { status: true, data: `User login successful` };
        // }
        // else {
        //     return { status: false, data: `User login failed` };
        // }
        return result;


    }

    catch (err) {
        console.error(err);
        throw err;
    }

}

module.exports = { registerUser, validateUser };