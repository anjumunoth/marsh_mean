// requires
var express = require('express');
var path = require("path");
var cors = require("cors");

var productsRouter = require("./routes/productRouter");
var usersRouter = require("./routes/userRouter");


// initialisations
var PORT = 3000;
var app = express();
var empArr = [{ empId: 101, empName: "Asha", salary: 1001, deptId: "D1" },
{ empId: 102, empName: "Gaurav", salary: 2000, deptId: "D1" },
{ empId: 103, empName: "Karan", salary: 2000, deptId: "D2" },
{ empId: 104, empName: "Kishan", salary: 3000, deptId: "D1" },
{ empId: 105, empName: "Keshav", salary: 3500, deptId: "D2" },
{ empId: 106, empName: "Pran", salary: 4000, deptId: "D3" },
{ empId: 107, empName: "Saurav", salary: 3800, deptId: "D3" }];
var corsOptions = {
    origin: "http://localhost:4200",

};



// middlewares
// inbuilt middlewares
app.use(express.static(path.join(__dirname, "public")));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
// add cors
app.use(cors(corsOptions));





// routes
app.use("/products", productsRouter);
app.use("/users", usersRouter);


app.get("/", (request, response) => {
    // send index.html
    var filePath = path.join(__dirname, "public", "index.html");
    response.sendFile(filePath);// default status code -- 200
})

app.get("/employees", (request, response) => {
    // json response
    response.json(empArr);
})

app.get("/about", (request, response) => {
    // json response
    response.status(401).send("Data not found");
    response.end();
})


app.get("/login", (request, response) => {
    var filePath = path.join(__dirname, "public", "login.html");
    response.sendFile(filePath);// default status code -- 200
});
console.log("hello");
app.post("/login", (request, response) => {
    console.log("Inside post request");
    console.log("Request as part of post request to login", request.body);
    response.end("Post request successful")
})






//listen
app.listen(PORT, (err) => {
    if (!err) {
        console.log("Server is running at PORT :" + PORT);
    }

})
