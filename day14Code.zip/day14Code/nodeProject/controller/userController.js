var { validateUser, registerUser } = require("../model/userModel");

async function checkUser(request, response) {
    var userObj = request.body;
    try {
        var result = await validateUser(userObj);
        if (result) {
            response.json({ status: true, message: "User login successful" });
        }
        else {
            response.status(401).json({ status: false, message: "User login failed" });
        }

    }
    catch (err) {
        response.status(500).json({ status: false, message: err.message });

    }
};
async function addUser(request, response) {
    var userObj = request.body;
    try {
        var result = await registerUser(userObj);
        response.json(result);
    }
    catch (err) {
        response.status(500).json({ status: false, message: err.message });

    }


};
module.exports = { addUser, checkUser }