var { insertProduct, getAllProducts, getAProduct } = require("../model/productModel");

async function addProduct(request, response) {

    try {
        var result = await insertProduct();
        response.json(result);

    }
    catch (err) {
        response.status(400).json(err.message);
    }


}




async function fetchAllProducts(request, response) {
    try {
        var resultArr = await getAllProducts();
        var resultObj;
        console.log("ResultArr in fetchAllProducts : ", resultArr);
        if (resultArr) {
            resultObj = {
                status: true,
                data: resultArr
            }
            response.json(resultObj);
        }
        else {

            resultObj = {
                status: false,
                data: []
            }
            response.json(resultObj);

        }


    }
    catch (err) {
        response.status(400).json(err);
    }
}

async function fetchAProduct(request, response) {

    try {
        var pId = parseInt(request.params.productId);
        var result = await getAProduct(pId);
        if (result) {
            var obj = { data: result }
            response.json(obj);
        }
        else {
            var obj = { data: null, message: `No product found with ProductId : ${pId}` };
            response.json(obj);;
        }

    }
    catch (err) {
        response.status(400).json(err);
    }
}

module.exports = {
    addProduct,
    fetchAllProducts,
    fetchAProduct
}

