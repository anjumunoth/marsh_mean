import { Component, inject } from '@angular/core';
import { Products } from '../model/Products';
import { Cart } from '../model/Cart';
import { Router } from '@angular/router';
import { ProductManagementService } from '../product-management.service';

@Component({
  selector: 'app-product-display',
  templateUrl: './product-display.component.html',
  styleUrls: ['./product-display.component.css']
})
export class ProductDisplayComponent {
  productsArr: Products[];
  companyName: string;
  showAddToCart: boolean;
  selectedProduct: Products | null;
  productManagementService: ProductManagementService;
  constructor(private router: Router) {
    this.productManagementService = inject(ProductManagementService)
    this.selectedProduct = null;
    this.companyName = "Marsh";
    this.showAddToCart = false;
    this.productsArr = this.productManagementService.getAllProductsItems();
  }
  addToCart(selectedProduct: Products) {
    alert("Button clicked" + selectedProduct.productName);
    this.showAddToCart = true;
    this.selectedProduct = selectedProduct;
  }
  changeCompanyName() {
    this.companyName = "Apple";
  }
  sendDataFromAddToCartToPDEventHandler(cartObj: Cart | null) {
    if (cartObj != null) {
      // update the quantity in productsArr
      var pos = this.productsArr.findIndex(product => product.productId == cartObj.productId);
      if (pos >= 0) {
        this.productsArr[pos].quantity = this.productsArr[pos].quantity - cartObj.quantitySelected;
      }

      // unmount the child component
      this.showAddToCart = false;
      // selectedProduct -- null
      this.selectedProduct = null;
    }
  }
  sendCancelEventFromAddToCartToPDEventHandler() {
    this.showAddToCart = false;
    this.selectedProduct = null;
  }
  detailsEventHandler(selectedProduct: Products) {
    // navigate to productdetails component
    this.router.navigate(["productDetails", selectedProduct.productId]);//productDetails/101

  }

}
