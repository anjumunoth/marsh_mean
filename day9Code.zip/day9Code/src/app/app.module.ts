import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { ProductDisplayComponent } from './product-display/product-display.component';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { CartComponent } from './cart/cart.component';
import { SearchArrPipe } from './search-arr.pipe';
import { SearchProductsComponent } from './search-products/search-products.component';
import { BgColorDirective } from './bg-color.directive';
import { DirectiveExamplesComponent } from './directive-examples/directive-examples.component';
import { TwoWayDataBindingExampleComponent } from './two-way-data-binding-example/two-way-data-binding-example.component';
import { EditProductComponent } from './edit-product/edit-product.component';
import { RegisterTemplateComponent } from './register-template/register-template.component';
import { RegisterModelComponent } from './register-model/register-model.component';
import { CheckEmailPatternDirective } from './check-email-pattern.directive';
import { MenuComponent } from './menu/menu.component';
import { MainHomeComponent } from './main-home/main-home.component';
import { PaymentsComponent } from './payments/payments.component';
import { PaymentByCardComponent } from './payment-by-card/payment-by-card.component';
import { PaymentByUPIComponent } from './payment-by-upi/payment-by-upi.component';
import { PaymentByWalletComponent } from './payment-by-wallet/payment-by-wallet.component';
import { PaymentByNetBankingComponent } from './payment-by-net-banking/payment-by-net-banking.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { CartManagementService } from './cart-management.service';
import { ProductManagementService } from './product-management.service';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    ProductDisplayComponent,
    AddToCartComponent,
    CartComponent,
    SearchArrPipe,
    SearchProductsComponent,
    BgColorDirective,
    DirectiveExamplesComponent,
    TwoWayDataBindingExampleComponent,
    EditProductComponent,
    RegisterTemplateComponent,
    RegisterModelComponent,
    CheckEmailPatternDirective,
    MenuComponent,
    MainHomeComponent,
    PaymentsComponent,
    PaymentByCardComponent,
    PaymentByUPIComponent,
    PaymentByWalletComponent,
    PaymentByNetBankingComponent,
    ProductDetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [CartManagementService, ProductManagementService],
  bootstrap: [AppComponent]
})
export class AppModule { }
